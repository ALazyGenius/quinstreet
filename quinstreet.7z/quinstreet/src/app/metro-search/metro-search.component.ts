import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-metro-search',
  templateUrl: './metro-search.component.html',
  styleUrls: ['./metro-search.component.css']
})
export class MetroSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
