import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetroSearchComponent } from './metro-search.component';

describe('MetroSearchComponent', () => {
  let component: MetroSearchComponent;
  let fixture: ComponentFixture<MetroSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetroSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetroSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
