import { Http } from '@angular/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataParserService {

  constructor(private http: Http) { }

  getTrainDetails() {
    return this.http.get('../../assets/data/metro.json');
  }
}
