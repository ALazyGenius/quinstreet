import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/Router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MetroHomeComponent } from './metro-home/metro-home.component';
import { MetroSearchComponent } from './metro-search/metro-search.component';

import { DataParserService } from './services/data-parser.service';

@NgModule({
  declarations: [
    AppComponent,
    MetroHomeComponent,
    MetroSearchComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: '',
        component: MetroHomeComponent
      }
    ])
  ],
  providers: [
    DataParserService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
