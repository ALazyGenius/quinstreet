import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetroHomeComponent } from './metro-home.component';

describe('MetroHomeComponent', () => {
  let component: MetroHomeComponent;
  let fixture: ComponentFixture<MetroHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetroHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetroHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
