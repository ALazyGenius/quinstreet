import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Component, OnInit } from "@angular/core";
import { DataParserService } from "../services/data-parser.service";

@Component({
  selector: "app-metro-home",
  templateUrl: "./metro-home.component.html",
  styleUrls: ["./metro-home.component.css"]
})
export class MetroHomeComponent implements OnInit {
  form = new FormGroup({
    to: new FormControl("", Validators.required),
    from: new FormControl("", Validators.required)
  });

  searchDisableFlag: boolean = true;
  trainData: any[] = [];
  fromStationSelected: string = "Null";
  toStationSelected: string = "Null";
  objectWithDetails: any = {};
  arrToStoreBreakUpRouteObjects: any[] = [];
  arrToStoreCOmpleteRouteDetails: any[] = [];
  counter: number = 0;
  results: Boolean = false;
  route: String = "";

  constructor(private metroService: DataParserService) {}

  ngOnInit() {
    this.metroService.getTrainDetails().subscribe(Response => {
      this.trainData = Response.json();
    });
  }

  fromChanged(event) {
    this.fromStationSelected = event.target.value;
    if (
      this.fromStationSelected != "Null" &&
      this.toStationSelected != "Null"
    ) {
      this.searchDisableFlag = false;
    } else {
      this.searchDisableFlag = true;
    }
  }

  toChanged(event) {
    this.toStationSelected = event.target.value;
    if (
      this.toStationSelected != "Null" &&
      this.fromStationSelected != "Null"
    ) {
      this.searchDisableFlag = false;
    } else {
      this.searchDisableFlag = true;
    }
  }

  onSubmit() {
    console.log(this.form);
    if (this.form.valid) {
      this.calculateRouteData(this.form.value);
    }
  }

  calculateRouteData(formData) {
    var fromStation = formData.from;
    var fromStationObj: any = {};
    var fromStationConnectedStationsList: any[] = [];
    var toStation = formData.to;
    for (var i = 0; i < this.trainData.length; i++) {
      if (fromStation === this.trainData[i].station) {
        fromStationObj = this.trainData[i];
      }
    }
    console.log(fromStationObj);
    fromStationConnectedStationsList = fromStationObj.connected.split(",");
    console.log(fromStationConnectedStationsList);
    for (var j = 0; j < fromStationConnectedStationsList.length; j++) {
      console.log(toStation);
      if (toStation == fromStationConnectedStationsList[j]) {
        alert("Direct Train is available between the 2 stations");
        this.processObjectForDirectRoute(
          toStation,
          fromStation,
          this.trainData
        );
        break;
      } else {
        alert("You have to break your journey");
        this.processObjectForBreakUpRoute(
          toStation,
          fromStation,
          this.trainData
        );
        break;
      }
    }
  }

  processObjectForDirectRoute(toStation, fromStation, trainData) {
    this.objectWithDetails = {};
    this.objectWithDetails["from"] = fromStation;
    this.objectWithDetails["to"] = toStation;
    this.objectWithDetails["shortestRoute"] =
      "A Direct Train is available between " +
      toStation +
      " and " +
      fromStation;
    console.log(this.objectWithDetails);
    this.results = true;
  }

  processObjectForBreakUpRoute(toStation, fromStation, trainData) {
    console.log(toStation);
    console.log(fromStation);
    var fromStationObj: any = {};
    for (var i = 0; i < trainData.length; i++) {
      if (fromStation === trainData[i].station) {
        fromStationObj = trainData[i];
      }
    }
    this.arrToStoreBreakUpRouteObjects.push(fromStationObj);
    while(this.arrToStoreCOmpleteRouteDetails.length > 1) {
      var count1 = 0;
      var count2 = 0;
      for(var x = 0; x < this.arrToStoreCOmpleteRouteDetails[0].length; x++) {
        if(this.arrToStoreCOmpleteRouteDetails[0][x] == "-")
          count1 += 1;
      }
      for(var x = 0; x < this.arrToStoreCOmpleteRouteDetails[1].length; x++) {
        if(this.arrToStoreCOmpleteRouteDetails[1][x] == "-")
          count2 += 1;
      }
      if(count1 > count2) {
        this.arrToStoreCOmpleteRouteDetails.splice(0,1);
      }
      else if(count1 < count2) {
        this.arrToStoreCOmpleteRouteDetails.splice(1,1);
      }
      else if(count1 == count2) {
        this.arrToStoreCOmpleteRouteDetails.splice(0,1);
      }
    }
    console.log(this.arrToStoreCOmpleteRouteDetails);
    var connectedStations = fromStationObj.connected.split(",");
    for (var l = 0; l < connectedStations.length; l++) {
      fromStation = connectedStations[l];
      if (fromStation != toStation) {
        this.processObjectForBreakUpRoute(toStation, fromStation, trainData);
      } else {
        for (var j = 0; j < this.arrToStoreBreakUpRouteObjects.length; j++) {
          this.route += this.arrToStoreBreakUpRouteObjects[j].station + "-";
          this.arrToStoreCOmpleteRouteDetails.push(this.route);
          console.log(this.arrToStoreCOmpleteRouteDetails);
          this.objectWithDetails = {};
          this.objectWithDetails["from"] = fromStation;
          this.objectWithDetails["to"] = toStation;
          this.objectWithDetails["shortestRoute"] =
            "Please prefer the following route " +
            this.arrToStoreCOmpleteRouteDetails[0]
          console.log(this.objectWithDetails);
          this.results = true;
        }
      }
    }
  }
}
